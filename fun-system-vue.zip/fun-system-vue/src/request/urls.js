let BASE_URL = require("./baseUrl").BASE_URL;

const LOGIN_URL = BASE_URL + '/user/login';


module.exports = {
    LOGIN_URL
}