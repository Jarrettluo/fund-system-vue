const BASE_URL = "http://192.168.101.14:8089"

exports.BASE_URL = BASE_URL;