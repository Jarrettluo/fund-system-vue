const BASE_URL = "http://129.211.165.193:8088"

exports.BASE_URL = BASE_URL;